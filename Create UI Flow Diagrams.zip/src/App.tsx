import { useState, type KeyboardEvent, type ReactNode } from "react";

type IconName =
  | "activity"
  | "box"
  | "chevron"
  | "copy"
  | "database"
  | "docs"
  | "github"
  | "grid"
  | "key"
  | "plus"
  | "server"
  | "settings"
  | "terminal";

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    activity: <><path d="M3 12h4l2.5-7 5 14 2.5-7h4" /></>,
    box: <><path d="m21 8-9 5-9-5 9-5 9 5Z" /><path d="m3 8 9 5 9-5v8l-9 5-9-5V8Z" /><path d="M12 13v8" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    copy: <><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M15 9V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h3" /></>,
    database: <><ellipse cx="12" cy="5" rx="8" ry="3" /><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5" /><path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" /></>,
    docs: <><path d="M6 2h9l4 4v16H6z" /><path d="M14 2v5h5M9 12h6M9 16h6" /></>,
    github: <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3.3-.4 6.8-1.6 6.8-7A5.4 5.4 0 0 0 19.3 4 5 5 0 0 0 19.2.5S18 0 15 2a13.4 13.4 0 0 0-7 0C5-.1 3.8.5 3.8.5A5 5 0 0 0 3.7 4a5.4 5.4 0 0 0-1.5 3.7c0 5.3 3.5 6.5 6.8 7A4.8 4.8 0 0 0 8 18v4" />,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
    key: <><circle cx="7.5" cy="15.5" r="4.5" /><path d="m10.7 12.3 8.8-8.8M15 8l3 3M18 5l3 3" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    server: <><rect x="3" y="4" width="18" height="6" rx="2" /><rect x="3" y="14" width="18" height="6" rx="2" /><path d="M7 7h.01M7 17h.01" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></>,
    terminal: <><path d="m4 17 6-6-6-6M12 19h8" /></>,
  };

  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

function Action({
  children,
  className = "",
  onClick,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if ((event.key === "Enter" || event.key === " ") && onClick) {
      event.preventDefault();
      onClick();
    }
  };
  return <div className={`action ${className}`} role="button" tabIndex={0} onClick={onClick} onKeyDown={onKeyDown}>{children}</div>;
}

function BrandMark() {
  return (
    <div className="brand-mark" aria-label="Japolic">
      <svg viewBox="0 0 48 48" aria-hidden="true">
        <path d="M20 2h8l2 5 5-3 6 6-3 5 6 2v14l-6 2 3 5-6 6-5-3-2 5h-8l-2-5-5 3-6-6 3-5-6-2V17l6-2-3-5 6-6 5 3 2-5Z" fill="currentColor" />
        <path d="M24 9 37 16.5v15L24 39 11 31.5v-15L24 9Z" fill="var(--ivory)" />
        <ellipse cx="24" cy="20" rx="6" ry="2.6" fill="currentColor" />
        <path d="M18 20v8c0 3 12 3 12 0v-8M18 24c0 3 12 3 12 0" fill="none" stroke="currentColor" strokeWidth="2" />
      </svg>
      <span>JAPOLIC</span>
    </div>
  );
}

const navItems: { icon: IconName; label: string }[] = [
  { icon: "grid", label: "Overview" },
  { icon: "database", label: "Storage" },
  { icon: "server", label: "Clusters" },
  { icon: "key", label: "Access keys" },
];

function App() {
  const [activeNav, setActiveNav] = useState("Overview");
  const [copied, setCopied] = useState(false);
  const [environment, setEnvironment] = useState("Production");

  const copyCommand = () => {
    navigator.clipboard?.writeText("curl -fsSL https://get.japolic.io | sh");
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-top">
          <BrandMark />
          <div className="workspace-switcher">
            <div className="workspace-avatar">A</div>
            <div className="workspace-copy">
              <strong>Acme systems</strong>
              <span>Developer workspace</span>
            </div>
            <Icon name="chevron" size={15} />
          </div>
          <nav className="nav-list" aria-label="Main navigation">
            {navItems.map((item) => (
              <Action key={item.label} className={`nav-item ${activeNav === item.label ? "active" : ""}`} onClick={() => setActiveNav(item.label)}>
                <Icon name={item.icon} />
                <span>{item.label}</span>
              </Action>
            ))}
          </nav>
        </div>
        <div className="sidebar-bottom">
          <Action className="nav-item"><Icon name="docs" /><span>Documentation</span><span className="external">↗</span></Action>
          <Action className="nav-item"><Icon name="settings" /><span>Settings</span></Action>
          <div className="support-card">
            <div className="support-icon"><Icon name="github" size={17} /></div>
            <strong>Built in the open</strong>
            <span>Explore the engine, report issues, or contribute.</span>
            <Action className="text-link">View on GitHub <span>↗</span></Action>
          </div>
          <div className="user-row">
            <div className="user-avatar">MK</div>
            <div><strong>Marcus Kim</strong><span>marcus@acme.dev</span></div>
            <span className="more">•••</span>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="mobile-brand"><BrandMark /></div>
          <div className="breadcrumb"><span>Acme systems</span><Icon name="chevron" size={13} /><strong>Overview</strong></div>
          <div className="top-actions">
            <div className="system-status"><span className="pulse" /> All systems operational</div>
            <Action className="icon-action"><Icon name="docs" /></Action>
            <Action className="primary-small"><Icon name="plus" size={16} /> Create storage</Action>
          </div>
        </header>

        <div className="content">
          <section className="welcome">
            <div>
              <span className="eyebrow">Infrastructure for developers</span>
              <div className="display-title">Good morning, Marcus.</div>
              <p>Your shared storage is healthy and moving data at local-disk speed.</p>
            </div>
            <div className="environment-control" aria-label="Environment selector">
              {["Production", "Staging"].map((item) => (
                <Action key={item} className={environment === item ? "selected" : ""} onClick={() => setEnvironment(item)}>
                  {item}
                </Action>
              ))}
            </div>
          </section>

          <section className="metric-grid">
            <div className="metric-card">
              <div className="metric-head"><span>Active storage</span><span className="metric-icon"><Icon name="database" /></span></div>
              <div className="metric-value">48.2 <small>TB</small></div>
              <div className="metric-foot"><span className="positive">↑ 12.4%</span> this month</div>
            </div>
            <div className="metric-card">
              <div className="metric-head"><span>Throughput</span><span className="metric-icon"><Icon name="activity" /></span></div>
              <div className="metric-value">18.6 <small>GB/s</small></div>
              <div className="sparkline" aria-label="Throughput trend">
                <svg viewBox="0 0 180 30" preserveAspectRatio="none"><path d="M0 25 20 20 38 23 57 12 75 16 92 7 112 13 132 4 150 10 180 2" /></svg>
              </div>
            </div>
            <div className="metric-card">
              <div className="metric-head"><span>Operations</span><span className="metric-icon"><Icon name="terminal" /></span></div>
              <div className="metric-value">2.4M <small>IOPS</small></div>
              <div className="metric-foot"><span className="positive">↑ 4.2%</span> vs last hour</div>
            </div>
            <div className="metric-card">
              <div className="metric-head"><span>Monthly estimate</span><span className="metric-icon"><Icon name="box" /></span></div>
              <div className="metric-value">$284</div>
              <div className="metric-foot"><span className="saving">Save 68%</span> vs managed cloud</div>
            </div>
          </section>

          <section className="dashboard-grid">
            <div className="panel topology-panel">
              <div className="panel-header">
                <div><div className="panel-title">Storage topology</div><p>Live data flow across your cluster</p></div>
                <Action className="secondary-small">View cluster <Icon name="chevron" size={14} /></Action>
              </div>
              <div className="topology">
                <div className="flow-label flow-one">12.4 GB/s</div>
                <div className="flow-label flow-two">6.2 GB/s</div>
                <svg className="flow-lines" viewBox="0 0 760 260" preserveAspectRatio="none" aria-hidden="true">
                  <path d="M128 64 C230 64 210 130 330 130" />
                  <path d="M128 198 C230 198 210 130 330 130" />
                  <path d="M430 130 C540 130 525 64 635 64" />
                  <path d="M430 130 C540 130 525 198 635 198" />
                </svg>
                <div className="node source source-one"><span className="node-icon"><Icon name="server" /></span><div><strong>Compute 01</strong><span>us-east-1a</span></div><i /></div>
                <div className="node source source-two"><span className="node-icon"><Icon name="server" /></span><div><strong>Compute 02</strong><span>us-east-1b</span></div><i /></div>
                <div className="core-node"><span className="core-icon"><BrandMark /></span><strong>Core volume</strong><span>48.2 TB · Healthy</span></div>
                <div className="node target target-one"><span className="node-icon amber"><Icon name="box" /></span><div><strong>analytics-prod</strong><span>S3 compatible</span></div><i /></div>
                <div className="node target target-two"><span className="node-icon amber"><Icon name="database" /></span><div><strong>training-data</strong><span>POSIX mount</span></div><i /></div>
              </div>
              <div className="topology-legend"><span><i className="legend-live" /> Live data path</span><span><i className="legend-node" /> 4 nodes online</span><span>Updated just now</span></div>
            </div>

            <div className="panel setup-panel">
              <div className="panel-header">
                <div><div className="panel-title">Quick start</div><p>Mount storage in under a minute</p></div>
                <span className="step-count">2 of 3</span>
              </div>
              <div className="progress"><span /></div>
              <div className="setup-steps">
                <div className="setup-step complete"><span className="step-dot">✓</span><div><strong>Create a volume</strong><span>analytics-prod · 32 TB</span></div></div>
                <div className="setup-step complete"><span className="step-dot">✓</span><div><strong>Generate an access key</strong><span>Key ending in 7F2A</span></div></div>
                <div className="setup-step current"><span className="step-dot">3</span><div><strong>Connect your first server</strong><span>Run this in your terminal</span></div></div>
              </div>
              <div className="code-block">
                <div className="code-top"><span>shell</span><Action className="copy-action" onClick={copyCommand}><Icon name="copy" size={14} />{copied ? "Copied" : "Copy"}</Action></div>
                <code><b>$</b> curl -fsSL https://get.japolic.io | sh</code>
              </div>
              <div className="setup-hint"><span>i</span><p>The CLI detects your environment and guides you through mounting the volume.</p></div>
              <Action className="primary-wide">Open installation guide <span>↗</span></Action>
            </div>
          </section>

          <section className="activity-panel panel">
            <div className="panel-header">
              <div><div className="panel-title">Recent activity</div><p>Changes across your infrastructure</p></div>
              <Action className="text-link dark">View all activity <Icon name="chevron" size={14} /></Action>
            </div>
            <div className="activity-row"><span className="activity-icon"><Icon name="server" /></span><div><strong>Node connected</strong><span>compute-02 joined the production cluster</span></div><code>node_8fa2</code><time>4 min ago</time></div>
            <div className="activity-row"><span className="activity-icon amber"><Icon name="database" /></span><div><strong>Volume resized</strong><span>analytics-prod increased from 24 TB to 32 TB</span></div><code>vol_a13c</code><time>2 hr ago</time></div>
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;
